#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include<sys/ioctl.h>

/*

---------------------------------------------------------------------------
	Commands	|	Parameter to be read	|
---------------------------------------------------------------------------
	GYRO_1		|	Gyroscope Axis 1	|
	GYRO_2		|	Gyroscope Axis 2	|
	GYRO_3		|	Gyroscope Axis 3	|
	ACC_1		|	Accelerometer Axis 1	|
	ACC_2		|	Accelerometer Axis 2   |
	ACC_3		|	Accelerometer Axis 3   |
	COM_1		|	Compass Axis 1         |
	COM_2		|       Compass Axis 2         |
	COM_3		|       Compass Axis 3         |
      PRESSURE		|	pressure               |  
*/

unsigned int value;
#define GYRO_1 _IOR('a','a',unsigned int*)
#define GYRO_2 _IOR('a','b',unsigned int*)
#define GYRO_3 _IOR('a','c',unsigned int*)
#define ACC_1 _IOR('a','d',unsigned int*)
#define ACC_2 _IOR('a','e',unsigned int*)
#define ACC_3 _IOR('a','f',unsigned int*)
#define COM_1 _IOR('a','g',unsigned int*)
#define COM_2 _IOR('a','h',unsigned int*)
#define COM_3 _IOR('a','i',unsigned int*)
#define PRESSURE _IOR('a','j',unsigned int*)
int main()
{
        int fd;
        int option;
        printf("**********************************\n");
        printf("****Extracting IMU sensor data****\n");

        fd = open("/dev/imu_char", O_RDWR);
        if(fd < 0) {
                printf("Cannot open device file...\n");
                return 0;
        }
        while(1) {
                printf("**********************************\n");
                
                printf("       1. Gyroscope axis_1        \n");
                printf("       2. Gyroscope axis_2        \n");
                printf("       3. Gyroscope axis_3        \n");
                printf("       4. Accelerometer axis_1    \n");
                printf("       5. Accelerometer axis_2    \n");
                printf("       6. Accelerometer axis_3    \n");
                printf("       7. Compass axis_1          \n");
                printf("       8. Compass axis_2          \n");
                printf("       9. Compass axis_3          \n");
                printf("      10. Pressure                \n");
                printf("       0.Exit                     \n");
                printf("Enter parameter value to be read from IMU\n");   
                scanf(" %d", &option);
                printf("Your Option = %d\n", option);
                
                switch(option) {
                        case 0:
                                close(fd);
                                exit(1);
                                break;                         
                        case 1:
                                printf("Reading Value from Gyroscope\n");
        			 ioctl(fd, GYRO_1, (unsigned int*) &value);
        			 printf("Gyrometer axis 1 Value is %u RPM\n", value); 
			         break;
                        case 2:
                                printf("Reading Value from Gyroscope\n");
        			 ioctl(fd, GYRO_2, (unsigned int*) &value);
        			 printf("Gyrometer axis 2 Value is %u RPM\n", value); 
			         break;
                        case 3:
                                printf("Reading Value from Gyroscope\n");
        			 ioctl(fd, GYRO_3, (unsigned int*) &value);
        			 printf("Gyrometer axis 3 Value is %u RPM\n", value); 
			         break;
                        case 4:
                                printf("Reading Value from Accelerometer\n");
        			 ioctl(fd, ACC_1, (unsigned int*) &value);
        			 printf("Accelorometer axis 1 Value is %u m/s2\n", value); 
			         break;			       			        
                        case 5:
                                printf("Reading Value from Accelerometer\n");
        			 ioctl(fd, ACC_2, (unsigned int*) &value);
        			 printf("Accelorometer axis 2 Value is %u m/s2\n", value); 
			         break;
                        case 6:
                                printf("Reading Value from Accelerometer\n");
        			 ioctl(fd, ACC_3, (unsigned int*) &value);
        			 printf("Accelorometer axis 3 Value is %u m/s2\n", value); 
			         break;			         
			         
                        case 7:
                                printf("Reading Value from Compass\n");
        			 ioctl(fd, COM_1, (unsigned int*) &value);
        			 printf("Compass axis 1 Value is %u deg\n", value); 
			         break;			         
			         			                    				 case 8:
                                printf("Reading Value from Compass\n");
        			 ioctl(fd, COM_2, (unsigned int*) &value);
        			 printf("Compass axis 2 Value is %u deg\n", value); 
			         break;
			 case 9:
                                printf("Reading Value from Compass\n");
        			 ioctl(fd, COM_3, (unsigned int*) &value);
        			 printf("Compass axis 3 Value is %u deg\n", value); 
			         break;			         
			 case 10:
                                printf("Reading Value from Barometer\n");
        			 ioctl(fd, PRESSURE, (unsigned int*) &value);
        			 printf("Pressure is %u Pa\n", value); 
			         break;			         			         
                        default:
                                printf("Enter Valid option = %c\n",option);
                                break;
                }
        }
        close(fd);
}
