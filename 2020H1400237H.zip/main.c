#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/module.h>
#include<linux/kdev_t.h>
#include<linux/fs.h>
#include<linux/cdev.h>
#include<linux/device.h>
#include<linux/slab.h>
#include<linux/uaccess.h>
#include<linux/random.h>


#define mem_size 1024
#define GYRO_1 _IOR('a','a',unsigned int*)
#define GYRO_2 _IOR('a','b',unsigned int*)
#define GYRO_3 _IOR('a','c',unsigned int*)
#define ACC_1 _IOR('a','d',unsigned int*)
#define ACC_2 _IOR('a','e',unsigned int*)
#define ACC_3 _IOR('a','f',unsigned int*)
#define COM_1 _IOR('a','g',unsigned int*)
#define COM_2 _IOR('a','h',unsigned int*)
#define COM_3 _IOR('a','i',unsigned int*)
#define PRESSURE _IOR('a','j',unsigned int*)

unsigned int gyro[3];
unsigned int acc[3];
unsigned int com[3];
unsigned int p;
static dev_t dev;
static struct cdev pcd_cdev;
static struct class *dev_class;
uint8_t *kernel_buff; 


static int __init imu_driver_init(void);
static void __exit imu_driver_exit(void);
static int permission(struct device* dev,struct kobj_uevent_env* env);
static int      imu_open(struct inode *inode, struct file *file);
static int      imu_close(struct inode *inode, struct file *file);
static ssize_t  imu_read(struct file *filp, char __user *buf, size_t len,loff_t * off);
static long imu_ioctl(struct file *file,unsigned int cmd,unsigned long arg);


static int permission(struct device* dev,struct kobj_uevent_env* env)
{
	add_uevent_var(env,"DEVMODE=%#o",0777);
	return 0;
} 

static int imu_open(struct inode *inode,struct file *file)
{
	printk(KERN_INFO"Device file is opened\n");
	return 0;	
}

static int imu_close(struct inode *inode,struct file *file)
{
	//kfree(kernel_buff);
	printk(KERN_INFO"Device file closed\n");
	return 0;
} 

static ssize_t imu_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
        pr_info("Read Function\n");
        return 0;
}

/*
** This function will be called when we write IOCTL on the Device file
*/
static long imu_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
         switch(cmd) {
                case GYRO_1:
                        get_random_bytes(&gyro[0],1);
                        gyro[0] = gyro[0] % 100;
                        if( copy_to_user((unsigned int*) arg, &gyro[0], sizeof(gyro[0])) )
                        {
                                pr_err("Gyro Axis 1 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Gyro Axis 1 Data :%u\n",gyro[0]);
                        }
                        break;
                case GYRO_2:
                        get_random_bytes(&gyro[1],1);
                        gyro[1] = gyro[1] % 100;
                        if( copy_to_user((unsigned int*) arg, &gyro[1], sizeof(gyro[1])) )
                        {
                                pr_err("Gyro Axis 2 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Gyro Axis 2 Data :%u\n",gyro[1]);
                        }
                        break;
                case GYRO_3:
                        get_random_bytes(&gyro[2],1);
                        gyro[2] = gyro[2] % 100;
                        if( copy_to_user((unsigned int*) arg, &gyro[2], sizeof(gyro[2])) )
                        {
                                pr_err("Gyro Axis 3 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Gyro Axis 3 Data :%u\n",gyro[2]);
                        }
                        break;
                case ACC_1:
                        get_random_bytes(&acc[0],1);
                        acc[0] = acc[0] % 50;
                        if( copy_to_user((unsigned int*) arg, &acc[0], sizeof(acc[0])) )
                        {
                                pr_err("Accelerometer Axis 1 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Accelerometer Axis 1 Data :%u\n",acc[0]);
                        }
                        break; 
                case ACC_2:
                        get_random_bytes(&acc[1],1);
                        acc[1] = acc[1] % 50;
                        if( copy_to_user((unsigned int*) arg, &acc[1], sizeof(acc[1])) )
                        {
                                pr_err("Accelerometer Axis 2 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Accelerometer Axis 2 Data :%u\n",acc[1]);
                        }
			 break;                       
                case ACC_3:
                        get_random_bytes(&acc[2],1);
                        acc[2] = acc[2] % 50;
                        if( copy_to_user((unsigned int*) arg, &acc[2], sizeof(acc[2])) )
                        {
                                pr_err("Accelerometer Axis 3 Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Accelerometer Axis 3 Data :%u\n",acc[2]);
                        }
			 break;                       
                case COM_1:
                        get_random_bytes(&com[0],1);
                        com[0] = com[0] % 360;
                        if( copy_to_user((unsigned int*) arg, &com[0], sizeof(com[0])) )
                        {
                                pr_err("Compass Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Compass Data :%u\n",com[0]);
                        }
                        break;
                case COM_2:
                        get_random_bytes(&com[1],1);
                        com[1] = com[1] % 360;
                        if( copy_to_user((unsigned int*) arg, &com[1], sizeof(com[1])) )
                        {
                                pr_err("Compass Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Compass Data :%u\n",com[1]);
                        }
                        break;                   
                case COM_3:
                        get_random_bytes(&com[2],1);
                        com[2] = com[2] % 360;
                        if( copy_to_user((unsigned int*) arg, &com[2], sizeof(com[2])) )
                        {
                                pr_err("Compass Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Compass Data :%u\n",com[2]);
                        }
                        break;                    
                case PRESSURE:
                        get_random_bytes(&p,1);
                        p = p % 1000;
                        if( copy_to_user((unsigned int*) arg, &p, sizeof(p)) )
                        {
                                pr_err("Barometer Read : Err!\n");
                        }
                        else
                        {
                        	pr_info("Pressure :%u\n",p);
                        }
                        break;                       						                                                                                                    
                default:
                        pr_info("Default\n");
                        break;
        }
        return 0;
}

/*
** File operation sturcture
*/
static struct file_operations fops =
{
	.owner          = THIS_MODULE,
	.open           = imu_open,
	.unlocked_ioctl = imu_ioctl,
	.release        = imu_close,
	.read           = imu_read
};

/*
** Module Init function
*/
static int __init imu_driver_init(void)
{
        /*Allocating Major number*/
        if((alloc_chrdev_region(&dev, 0, 1, "imuc_dev")) <0){
                pr_err("Cannot allocate major number\n");
                return -1;
        }
        pr_info("Major = %d Minor = %d \n",MAJOR(dev), MINOR(dev));

        /*Creating cdev structure*/
        cdev_init(&pcd_cdev,&fops);

        /*Adding character device to the system*/
        if((cdev_add(&pcd_cdev,dev,1)) < 0){
            pr_err("Cannot add the device to the system\n");
            goto r_class;
        }

        /*Creating struct class*/
        if((dev_class = class_create(THIS_MODULE,"pcd_class")) == NULL){
            pr_err("Cannot create the struct class\n");
            goto r_class;
        }

        /*Creating device*/
        if((device_create(dev_class,NULL,dev,NULL,"imu_char")) == NULL){
            pr_err("Cannot create the Device 1\n");
            goto r_device;
        }
        pr_info("Device Driver Insert...Done!!!\n");
      return 0;

r_device:
        class_destroy(dev_class);
r_class:
        unregister_chrdev_region(dev,1);
        return -1;
}

/*
** Module exit function
*/
static void __exit imu_driver_exit(void)
{
        device_destroy(dev_class,dev);
        class_destroy(dev_class);
        cdev_del(&pcd_cdev);
        unregister_chrdev_region(dev, 1);
        pr_info("Device Driver Remove...Done!!!\n");
}

module_init(imu_driver_init);
module_exit(imu_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rajasekar");
MODULE_DESCRIPTION("IMU character device driver");
MODULE_VERSION("1.3");

